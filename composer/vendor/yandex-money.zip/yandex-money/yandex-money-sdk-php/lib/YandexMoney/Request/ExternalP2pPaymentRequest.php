<?php

namespace YandexMoney\Request;


class ExternalP2pPaymentRequest extends PaymentRequest {


} 