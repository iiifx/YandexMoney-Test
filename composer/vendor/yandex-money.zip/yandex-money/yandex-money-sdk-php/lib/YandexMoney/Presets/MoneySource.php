<?php

namespace YandexMoney\Presets;

class MoneySource
{
    const WALLET = "wallet";
    const CARD = "card";
} 