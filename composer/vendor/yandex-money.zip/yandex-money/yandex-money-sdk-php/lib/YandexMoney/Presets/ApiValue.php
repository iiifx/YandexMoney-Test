<?php

namespace YandexMoney\Presets;


class ApiValue
{
    const AUTHORIZATION_CODE = 'authorization_code';
    const P2P = 'p2p';
    const WALLET = 'wallet';
    const CARD = 'card';
    const PHONE_TOPUP  = 'phone-topup';
} 