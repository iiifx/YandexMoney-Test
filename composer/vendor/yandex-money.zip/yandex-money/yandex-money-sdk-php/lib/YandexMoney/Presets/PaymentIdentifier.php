<?php

namespace YandexMoney\Presets;


class PaymentIdentifier
{
    const ACCOUNT = "account";
    const PHONE = "phone";
    const PATTERN = "pattern";
} 