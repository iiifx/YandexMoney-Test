<?php

namespace YandexMoney\Exception;


class InvalidMethodInputException extends \Exception
{

} 