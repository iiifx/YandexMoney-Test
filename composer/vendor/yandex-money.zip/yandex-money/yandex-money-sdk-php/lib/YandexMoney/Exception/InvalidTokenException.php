<?php

namespace YandexMoney\Exception;

/**
 * 
 */
class InvalidTokenException extends Exception
{
}
