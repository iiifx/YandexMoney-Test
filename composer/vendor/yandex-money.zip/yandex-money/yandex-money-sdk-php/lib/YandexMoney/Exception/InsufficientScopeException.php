<?php

namespace YandexMoney\Exception;

/**
 * 
 */
class InsufficientScopeException extends Exception
{
}