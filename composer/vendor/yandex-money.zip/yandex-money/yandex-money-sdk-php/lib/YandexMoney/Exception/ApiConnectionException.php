<?php

namespace YandexMoney\Exception;

/**
 * 
 */
class ApiConnectionException extends Exception
{
}