<?php

namespace YandexMoney\Exception;

/**
 * 
 */
class ApiException extends Exception
{
}