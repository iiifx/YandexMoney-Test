<?php

namespace YandexMoney\Exception;

/**
 * 
 */
class InternalServerErrorException extends Exception
{
}
