# Changelog

## 1.3.0 (18.03.2014)

* composer support
* php >= 5.3.0 requirement
* details flag added in operation-history method
* several minor docs and code changes
* sample project improved

## 1.2.5 (27.12.2013)

* certificate chain updated

## 1.2.4 (28.10.2013)

* fixed undefined variable $resp at ApiRequestor

## 1.2.3 (15.08.2013)

* create log file instead of exception throwing

## 1.2.2 (03.08.2013)

* revokeOAuthToken exception fixed

## 1.2.1 (09.01.2013)

* request logs added

## 1.2.0 (29.05.2012)

* revoke token method added

## 1.1.0 (09.04.2012)

* source code refactoring
* credit card payments to shops

## 1.0.0 (28.10.2012)

* php-lib release